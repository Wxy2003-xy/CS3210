#define VECT_SIZE   2000000
#define VECT_NAME   "vector.dat"

